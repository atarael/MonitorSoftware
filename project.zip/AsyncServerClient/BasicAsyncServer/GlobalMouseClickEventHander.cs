﻿namespace BasicAsyncServer
{
    public class GlobalMouseClickEventHander
    {
    }
}